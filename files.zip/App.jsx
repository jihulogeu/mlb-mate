import { useState, useRef, useEffect } from 'react'
import './App.css'
import WelcomeCard    from './components/WelcomeCard.jsx'
import ChatMessage    from './components/ChatMessage.jsx'
import TypingIndicator from './components/TypingIndicator.jsx'
import ChatInput      from './components/ChatInput.jsx'

// Placeholder AI responses (replace with real API later)
const DEMO_REPLIES = [
  '응원팀이 등록되었어요! 이제 "오늘 경기 어때?" 처럼 간단히 물어보세요 ⚾',
  '현재 MLB API와 연결 중입니다. 잠시 후 실제 데이터를 가져올 예정이에요!',
  '선발투수 정보와 경기 일정을 곧 제공할 수 있을 거예요. 기대해 주세요! 🙌',
  '아직 개발 중인 기능입니다. MLB API 연동 후 정확한 정보를 드릴게요.',
]

function makeMessage(role, text) {
  return { id: Date.now() + Math.random(), role, text, timestamp: new Date() }
}

export default function App() {
  const [messages,  setMessages]  = useState([])
  const [input,     setInput]     = useState('')
  const [isTyping,  setIsTyping]  = useState(false)
  const bottomRef = useRef(null)
  const replyIndex = useRef(0)

  // Scroll to bottom whenever messages or typing state changes
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isTyping])

  function handleExampleClick(text) {
    setInput(text)
  }

  async function handleSend() {
    const text = input.trim()
    if (!text || isTyping) return

    // Add user message
    setMessages(prev => [...prev, makeMessage('user', text)])
    setInput('')
    setIsTyping(true)

    // Simulate network delay (replace with real API call later)
    await new Promise(resolve => setTimeout(resolve, 900 + Math.random() * 600))

    const reply = DEMO_REPLIES[replyIndex.current % DEMO_REPLIES.length]
    replyIndex.current++

    setIsTyping(false)
    setMessages(prev => [...prev, makeMessage('ai', reply)])
  }

  return (
    <div className="app">
      {/* ── Header ── */}
      <header className="header">
        <span className="header-logo">⚾</span>
        <h1 className="header-title">MLB<span> Mate</span></h1>
        <span className="header-badge">Beta</span>
      </header>

      {/* ── Chat Window ── */}
      <main className="chat-window">
        <WelcomeCard onExampleClick={handleExampleClick} />

        {messages.map(msg => (
          <ChatMessage key={msg.id} message={msg} />
        ))}

        {isTyping && <TypingIndicator />}

        <div ref={bottomRef} />
      </main>

      {/* ── Input Area ── */}
      <ChatInput
        value={input}
        onChange={setInput}
        onSend={handleSend}
        disabled={isTyping}
      />
    </div>
  )
}
